import telebot

bot = telebot.TeleBot('6086212674:AAGoWZEl7q8eqn3wyvhWwXxoFwCvW5Im4lc') # Укажите ваш токен бота
OWNER_ID = 5926352552
CHAT_GROUP_ID = -1001623914047

